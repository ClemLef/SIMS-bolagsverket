﻿namespace StudentManagementApp.Library.Models
{
    public class Course
    {
    }
}
